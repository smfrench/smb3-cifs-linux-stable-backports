// SPDX-License-Identifier: GPL-2.0
/*
 *   Copyright (C) 2018, Microsoft Corporation.
 *
 *   Author(s): Steve French <stfrench@microsoft.com>
 */
#define CREATE_TRACE_POINTS
#include "trace.h"
